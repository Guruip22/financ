'use client';

import { useEffect, useState } from 'react';
import { Transaction, ClosedTrade, Alert, PortfolioData, Position } from '@/lib/types';
import { loadPortfolioData, savePortfolioData } from '@/lib/storage';
import { fetchAllPrices } from '@/lib/market-data';
import { calculatePositions, processSale } from '@/lib/calculations';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DarkModeToggle } from '@/components/dark-mode-toggle';
import { TransactionForm } from '@/components/transaction-form';
import { PortfolioDashboard } from '@/components/portfolio-dashboard';
import { TransactionHistory } from '@/components/transaction-history';
import { RealizedReturns } from '@/components/realized-returns';
import { Alerts } from '@/components/alerts';
import { TrendingUp } from 'lucide-react';

export default function Home() {
  const [data, setData] = useState<PortfolioData>({
    transactions: [],
    closedTrades: [],
    alertas: {}
  });
  const [currentPrices, setCurrentPrices] = useState<Record<string, number>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [mounted, setMounted] = useState(false);

  // Load data on mount
  useEffect(() => {
    setMounted(true);
    const loaded = loadPortfolioData();
    setData(loaded);
    updatePrices();
  }, []);

  const updatePrices = async () => {
    setIsLoading(true);
    try {
      const priceMap = await fetchAllPrices();
      const prices: Record<string, number> = {};
      Object.entries(priceMap).forEach(([ticker, data]) => {
        if (data.c) prices[ticker] = data.c;
      });
      setCurrentPrices(prices);
    } catch (error) {
      console.error('Error updating prices:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddTransaction = (transaction: Transaction) => {
    let newClosedTrades: ClosedTrade[] = [];

    // If it's a sell, calculate realized P/L using FIFO
    if (transaction.type === 'venta') {
      newClosedTrades = processSale(
        transaction.ticker,
        transaction.cantidad,
        transaction.precio,
        transaction.fecha,
        transaction.fees || 0,
        data.transactions
      );
    }

    const newData = {
      ...data,
      transactions: [...data.transactions, transaction],
      closedTrades: [...data.closedTrades, ...newClosedTrades]
    };

    setData(newData);
    savePortfolioData(newData);
  };

  const handleDeleteTransaction = (id: string) => {
    // Find the transaction to delete
    const txnToDelete = data.transactions.find(t => t.id === id);
    if (!txnToDelete) return;

    // Remove the transaction
    const newTransactions = data.transactions.filter(t => t.id !== id);

    // If it was a sell, we need to recalculate all closed trades
    // For simplicity, we'll remove closed trades related to this sale
    let newClosedTrades = data.closedTrades;
    
    if (txnToDelete.type === 'venta') {
      // Remove closed trades from this date onwards for this ticker
      newClosedTrades = data.closedTrades.filter(
        ct => !(ct.ticker === txnToDelete.ticker && ct.date === txnToDelete.fecha)
      );
    }

    const newData = {
      ...data,
      transactions: newTransactions,
      closedTrades: newClosedTrades
    };

    setData(newData);
    savePortfolioData(newData);
  };

  const handleUpdateAlert = (ticker: string, alert: Alert) => {
    const newData = {
      ...data,
      alertas: {
        ...data.alertas,
        [ticker]: alert
      }
    };
    setData(newData);
    savePortfolioData(newData);
  };

  const handleDeleteAlert = (ticker: string) => {
    const newAlertas = { ...data.alertas };
    delete newAlertas[ticker];
    
    const newData = {
      ...data,
      alertas: newAlertas
    };
    setData(newData);
    savePortfolioData(newData);
  };

  // Calculate portfolio metrics
  const positions = calculatePositions(data.transactions, currentPrices);
  const totalValue = positions.reduce((sum, p) => sum + p.currentValue, 0);
  const totalInvested = positions.reduce((sum, p) => sum + p.investedCapital, 0);
  const totalUnrealizedPL = positions.reduce((sum, p) => sum + p.unrealizedPL, 0);

  if (!mounted) {
    return null; // Prevent hydration mismatch
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <TrendingUp className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">MiInversiones AR</h1>
                <p className="text-sm text-muted-foreground">Portfolio Tracker - Mercado Argentino</p>
              </div>
            </div>
            <DarkModeToggle />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="transactions">Transacciones</TabsTrigger>
            <TabsTrigger value="history">Historial</TabsTrigger>
            <TabsTrigger value="returns">Rendimientos</TabsTrigger>
            <TabsTrigger value="alerts">Alertas</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <PortfolioDashboard
              positions={positions}
              totalValue={totalValue}
              totalInvested={totalInvested}
              totalUnrealizedPL={totalUnrealizedPL}
              onUpdatePrices={updatePrices}
              isLoading={isLoading}
            />
          </TabsContent>

          <TabsContent value="transactions">
            <TransactionForm onSubmit={handleAddTransaction} />
          </TabsContent>

          <TabsContent value="history">
            <TransactionHistory
              transactions={data.transactions}
              onDelete={handleDeleteTransaction}
            />
          </TabsContent>

          <TabsContent value="returns">
            <RealizedReturns closedTrades={data.closedTrades} />
          </TabsContent>

          <TabsContent value="alerts">
            <Alerts
              alertas={data.alertas}
              currentPrices={currentPrices}
              onUpdate={handleUpdateAlert}
              onDelete={handleDeleteAlert}
            />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card mt-16">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              Cotizaciones educativas de{' '}
              <a
                href="https://data912.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                data912.com
              </a>
              {' '}(no real-time, refresh ~20s)
            </p>
            <p className="text-sm text-muted-foreground">
              Uso personal/educativo. <strong>No consejo financiero.</strong> Cálculos aproximados - verifique con su broker.
            </p>
            <p className="text-xs text-muted-foreground">
              Hecho con ❤️ por{' '}
              <a
                href="https://twitter.com/Guru_itm"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                @Guru_itm
              </a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
