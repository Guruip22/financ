'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Transaction } from '@/lib/types';
import { formatCurrency } from '@/lib/calculations';
import { format, parseISO } from 'date-fns';
import { Trash2, Download } from 'lucide-react';
import { Button } from './ui/button';
import { exportToCSV } from '@/lib/calculations';

interface TransactionHistoryProps {
  transactions: Transaction[];
  onDelete: (id: string) => void;
}

export function TransactionHistory({ transactions, onDelete }: TransactionHistoryProps) {
  const [filterTicker, setFilterTicker] = useState('');
  const [filterDate, setFilterDate] = useState('');

  const filteredTransactions = transactions.filter(t => {
    const matchesTicker = !filterTicker || t.ticker.toUpperCase().includes(filterTicker.toUpperCase());
    const matchesDate = !filterDate || t.fecha.startsWith(filterDate);
    return matchesTicker && matchesDate;
  }).sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());

  const handleExport = () => {
    const exportData = filteredTransactions.map(t => ({
      Fecha: format(parseISO(t.fecha), 'yyyy-MM-dd'),
      Ticker: t.ticker,
      Tipo: t.type,
      Cantidad: t.cantidad,
      Precio: t.precio,
      Comisiones: t.fees || 0,
      Total: t.type === 'compra' 
        ? (t.precio * t.cantidad) + (t.fees || 0)
        : (t.precio * t.cantidad) - (t.fees || 0),
      Nota: t.nota || ''
    }));
    exportToCSV(exportData, `transacciones-${format(new Date(), 'yyyy-MM-dd')}.csv`);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Historial de Transacciones</CardTitle>
          <CardDescription>Todas sus operaciones registradas</CardDescription>
        </div>
        {transactions.length > 0 && (
          <Button onClick={handleExport} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exportar CSV
          </Button>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="filter-ticker">Filtrar por Ticker</Label>
              <Input
                id="filter-ticker"
                placeholder="GGAL, YPFD..."
                value={filterTicker}
                onChange={(e) => setFilterTicker(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="filter-date">Filtrar por Fecha</Label>
              <Input
                id="filter-date"
                type="date"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
              />
            </div>
          </div>

          {/* Table */}
          {filteredTransactions.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              {transactions.length === 0 
                ? 'No hay transacciones registradas.'
                : 'No se encontraron transacciones con los filtros aplicados.'}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Ticker</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead className="text-right">Cantidad</TableHead>
                    <TableHead className="text-right">Precio</TableHead>
                    <TableHead className="text-right">Comisiones</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead>Nota</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.map((transaction) => {
                    const total = transaction.type === 'compra'
                      ? (transaction.precio * transaction.cantidad) + (transaction.fees || 0)
                      : (transaction.precio * transaction.cantidad) - (transaction.fees || 0);
                    
                    return (
                      <TableRow key={transaction.id}>
                        <TableCell>{format(parseISO(transaction.fecha), 'dd/MM/yyyy')}</TableCell>
                        <TableCell className="font-medium">{transaction.ticker}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            transaction.type === 'compra' 
                              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                              : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                          }`}>
                            {transaction.type === 'compra' ? 'Compra' : 'Venta'}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">{transaction.cantidad}</TableCell>
                        <TableCell className="text-right">{formatCurrency(transaction.precio)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(transaction.fees || 0)}</TableCell>
                        <TableCell className={`text-right font-medium ${
                          transaction.type === 'compra' ? 'text-red-600' : 'text-green-600'
                        }`}>
                          {transaction.type === 'compra' ? '-' : '+'}{formatCurrency(total)}
                        </TableCell>
                        <TableCell className="max-w-xs truncate">{transaction.nota || '-'}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              if (confirm('¿Está seguro que desea eliminar esta transacción?')) {
                                onDelete(transaction.id);
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4 text-red-600" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
