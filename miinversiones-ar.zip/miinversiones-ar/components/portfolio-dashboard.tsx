'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Position } from '@/lib/types';
import { formatCurrency, formatPercent } from '@/lib/calculations';
import { TrendingUp, TrendingDown, DollarSign, BarChart, AlertTriangle } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart as RechartsBar, Bar, XAxis, YAxis, CartesianGrid, Legend } from 'recharts';

interface PortfolioDashboardProps {
  positions: Position[];
  totalValue: number;
  totalInvested: number;
  totalUnrealizedPL: number;
  onUpdatePrices: () => void;
  isLoading?: boolean;
}

const COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4', '#ec4899', '#6366f1'];

export function PortfolioDashboard({ 
  positions, 
  totalValue, 
  totalInvested, 
  totalUnrealizedPL,
  onUpdatePrices,
  isLoading 
}: PortfolioDashboardProps) {
  const overallPercent = totalInvested > 0 ? (totalUnrealizedPL / totalInvested) * 100 : 0;

  const pieData = positions.map(p => ({
    name: p.ticker,
    value: p.currentValue
  }));

  const barData = positions.map(p => ({
    ticker: p.ticker,
    pl: p.unrealizedPL
  }));

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valor Total</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalValue)}</div>
            <p className="text-xs text-muted-foreground mt-1">Portfolio total</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Capital Invertido</CardTitle>
            <BarChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalInvested)}</div>
            <p className="text-xs text-muted-foreground mt-1">Costo total + comisiones</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">P/L No Realizado</CardTitle>
            {totalUnrealizedPL >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-600" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-600" />
            )}
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${totalUnrealizedPL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(totalUnrealizedPL)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Ganancia/Pérdida actual</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rendimiento %</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${overallPercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatPercent(overallPercent)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Retorno sobre inversión</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      {positions.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Distribución del Portfolio</CardTitle>
              <CardDescription>Asignación por activo</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(value as number)} />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>P/L No Realizado por Activo</CardTitle>
              <CardDescription>Ganancia/Pérdida actual</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <RechartsBar data={barData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="ticker" />
                  <YAxis tickFormatter={(value) => formatCurrency(value)} />
                  <Tooltip formatter={(value) => formatCurrency(value as number)} />
                  <Bar dataKey="pl" fill="#10b981" />
                </RechartsBar>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Positions Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Posiciones Actuales</CardTitle>
            <CardDescription>Vista consolidada de su portfolio</CardDescription>
          </div>
          <button
            onClick={onUpdatePrices}
            disabled={isLoading}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 disabled:opacity-50"
          >
            {isLoading ? 'Actualizando...' : 'Actualizar Cotizaciones'}
          </button>
        </CardHeader>
        <CardContent>
          {positions.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No hay posiciones abiertas. Agregue transacciones para comenzar.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ticker</TableHead>
                    <TableHead className="text-right">Cantidad</TableHead>
                    <TableHead className="text-right">Precio Prom. Compra</TableHead>
                    <TableHead className="text-right">Precio Actual</TableHead>
                    <TableHead className="text-right">Valor Actual</TableHead>
                    <TableHead className="text-right">P/L No Realizado</TableHead>
                    <TableHead className="text-right">%</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {positions.map((position) => (
                    <TableRow key={position.ticker}>
                      <TableCell className="font-medium">{position.ticker}</TableCell>
                      <TableCell className="text-right">{position.quantity}</TableCell>
                      <TableCell className="text-right">{formatCurrency(position.avgBuyPrice)}</TableCell>
                      <TableCell className="text-right">
                        {position.currentPrice > 0 ? formatCurrency(position.currentPrice) : 'N/A'}
                      </TableCell>
                      <TableCell className="text-right">{formatCurrency(position.currentValue)}</TableCell>
                      <TableCell className={`text-right font-medium ${position.unrealizedPL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(position.unrealizedPL)}
                      </TableCell>
                      <TableCell className={`text-right font-medium ${position.unrealizedPLPercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatPercent(position.unrealizedPLPercent)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
          <p className="text-xs text-muted-foreground mt-4">
            <strong>Nota:</strong> Precios aproximados - verificar en broker. Actualización ~20s.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
