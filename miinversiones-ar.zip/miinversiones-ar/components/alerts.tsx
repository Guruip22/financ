'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Alert } from '@/lib/types';
import { formatCurrency } from '@/lib/calculations';
import { AlertTriangle, Trash2, TrendingDown, TrendingUp } from 'lucide-react';

interface AlertsProps {
  alertas: Record<string, Alert>;
  currentPrices: Record<string, number>;
  onUpdate: (ticker: string, alert: Alert) => void;
  onDelete: (ticker: string) => void;
}

export function Alerts({ alertas, currentPrices, onUpdate, onDelete }: AlertsProps) {
  const [ticker, setTicker] = useState('');
  const [stopLoss, setStopLoss] = useState('');
  const [target, setTarget] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!ticker) {
      alert('Ingrese un ticker');
      return;
    }

    const alert: Alert = {};
    if (stopLoss) alert.stopLoss = parseFloat(stopLoss);
    if (target) alert.target = parseFloat(target);

    if (Object.keys(alert).length === 0) {
      alert('Ingrese al menos un Stop Loss o Target Price');
      return;
    }

    onUpdate(ticker.toUpperCase(), alert);
    
    setTicker('');
    setStopLoss('');
    setTarget('');
  };

  // Check for triggered alerts
  const triggeredAlerts: Array<{ ticker: string; type: 'stopLoss' | 'target'; currentPrice: number; alertPrice: number }> = [];
  
  Object.entries(alertas).forEach(([ticker, alert]) => {
    const currentPrice = currentPrices[ticker];
    if (currentPrice) {
      if (alert.stopLoss && currentPrice <= alert.stopLoss) {
        triggeredAlerts.push({
          ticker,
          type: 'stopLoss',
          currentPrice,
          alertPrice: alert.stopLoss
        });
      }
      if (alert.target && currentPrice >= alert.target) {
        triggeredAlerts.push({
          ticker,
          type: 'target',
          currentPrice,
          alertPrice: alert.target
        });
      }
    }
  });

  return (
    <div className="space-y-6">
      {/* Triggered Alerts Banner */}
      {triggeredAlerts.length > 0 && (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-yellow-600 dark:text-yellow-500 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold text-yellow-900 dark:text-yellow-200">Alertas Activadas</h3>
              <ul className="mt-2 space-y-1 text-sm text-yellow-800 dark:text-yellow-300">
                {triggeredAlerts.map((alert, idx) => (
                  <li key={idx}>
                    <strong>{alert.ticker}:</strong>{' '}
                    {alert.type === 'stopLoss' 
                      ? `Stop Loss alcanzado (${formatCurrency(alert.alertPrice)} - actual: ${formatCurrency(alert.currentPrice)})`
                      : `Target Price alcanzado (${formatCurrency(alert.alertPrice)} - actual: ${formatCurrency(alert.currentPrice)})`
                    }
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Add Alert Form */}
      <Card>
        <CardHeader>
          <CardTitle>Configurar Alerta</CardTitle>
          <CardDescription>Establezca Stop Loss y/o Target Price por ticker</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="alert-ticker">Ticker</Label>
                <Input
                  id="alert-ticker"
                  placeholder="GGAL"
                  value={ticker}
                  onChange={(e) => setTicker(e.target.value.toUpperCase())}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stop-loss">Stop Loss (ARS)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                  <Input
                    id="stop-loss"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="1000.00"
                    className="pl-7"
                    value={stopLoss}
                    onChange={(e) => setStopLoss(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="target">Target Price (ARS)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                  <Input
                    id="target"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="1500.00"
                    className="pl-7"
                    value={target}
                    onChange={(e) => setTarget(e.target.value)}
                  />
                </div>
              </div>
            </div>

            <Button type="submit" className="w-full md:w-auto">
              Guardar Alerta
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Active Alerts Table */}
      <Card>
        <CardHeader>
          <CardTitle>Alertas Activas</CardTitle>
          <CardDescription>Monitoreo de precios objetivo</CardDescription>
        </CardHeader>
        <CardContent>
          {Object.keys(alertas).length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No hay alertas configuradas. Agregue una para comenzar a monitorear precios.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ticker</TableHead>
                    <TableHead className="text-right">Precio Actual</TableHead>
                    <TableHead className="text-right">Stop Loss</TableHead>
                    <TableHead className="text-right">Target Price</TableHead>
                    <TableHead className="text-center">Estado</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(alertas).map(([ticker, alert]) => {
                    const currentPrice = currentPrices[ticker];
                    const stopLossTriggered = alert.stopLoss && currentPrice && currentPrice <= alert.stopLoss;
                    const targetTriggered = alert.target && currentPrice && currentPrice >= alert.target;

                    return (
                      <TableRow key={ticker}>
                        <TableCell className="font-medium">{ticker}</TableCell>
                        <TableCell className="text-right">
                          {currentPrice ? formatCurrency(currentPrice) : 'N/A'}
                        </TableCell>
                        <TableCell className="text-right">
                          {alert.stopLoss ? (
                            <span className={stopLossTriggered ? 'text-red-600 font-semibold' : ''}>
                              {formatCurrency(alert.stopLoss)}
                            </span>
                          ) : '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          {alert.target ? (
                            <span className={targetTriggered ? 'text-green-600 font-semibold' : ''}>
                              {formatCurrency(alert.target)}
                            </span>
                          ) : '-'}
                        </TableCell>
                        <TableCell className="text-center">
                          {stopLossTriggered && (
                            <span className="inline-flex items-center gap-1 text-xs font-medium text-red-600">
                              <TrendingDown className="h-4 w-4" />
                              Stop Loss
                            </span>
                          )}
                          {targetTriggered && (
                            <span className="inline-flex items-center gap-1 text-xs font-medium text-green-600">
                              <TrendingUp className="h-4 w-4" />
                              Target
                            </span>
                          )}
                          {!stopLossTriggered && !targetTriggered && (
                            <span className="text-xs text-muted-foreground">Normal</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              if (confirm(`¿Eliminar alerta para ${ticker}?`)) {
                                onDelete(ticker);
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4 text-red-600" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
