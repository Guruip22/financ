'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ClosedTrade } from '@/lib/types';
import { formatCurrency, formatPercent, groupRealizedByPeriod, exportToCSV } from '@/lib/calculations';
import { format, parseISO } from 'date-fns';
import { TrendingUp, TrendingDown, Download, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface RealizedReturnsProps {
  closedTrades: ClosedTrade[];
}

export function RealizedReturns({ closedTrades }: RealizedReturnsProps) {
  const [period, setPeriod] = useState<'day' | 'month' | 'year'>('month');

  // Calculate totals
  const totalRealizedPL = closedTrades.reduce((sum, t) => sum + t.realizedPL, 0);
  const totalClosedTrades = closedTrades.length;
  
  // Group by period
  const groupedData = groupRealizedByPeriod(closedTrades, period);
  
  // Find best and worst periods
  let bestPeriod = { period: '-', pl: 0 };
  let worstPeriod = { period: '-', pl: 0 };
  
  groupedData.forEach((value, key) => {
    if (value.totalPL > bestPeriod.pl) {
      bestPeriod = { period: key, pl: value.totalPL };
    }
    if (value.totalPL < worstPeriod.pl) {
      worstPeriod = { period: key, pl: value.totalPL };
    }
  });

  // Prepare chart data
  const periodData = Array.from(groupedData.entries())
    .map(([key, value]) => ({
      period: key,
      pl: value.totalPL,
      avgPercent: value.avgPercent,
      count: value.trades.length
    }))
    .sort((a, b) => a.period.localeCompare(b.period));

  // Cumulative data for line chart
  let cumulative = 0;
  const cumulativeData = periodData.map(item => {
    cumulative += item.pl;
    return {
      period: item.period,
      cumulative
    };
  });

  const handleExport = () => {
    const exportData = closedTrades.map(t => ({
      Fecha: format(parseISO(t.date), 'yyyy-MM-dd'),
      Ticker: t.ticker,
      'Cantidad Vendida': t.quantitySold,
      'Precio Compra Promedio': t.buyPriceAvg,
      'Precio Venta': t.sellPrice,
      'P/L Realizado': t.realizedPL,
      '% Retorno': t.percentPL,
      Comisiones: t.fees
    }));
    exportToCSV(exportData, `rendimientos-realizados-${format(new Date(), 'yyyy-MM-dd')}.csv`);
  };

  const formatPeriodLabel = (periodKey: string) => {
    if (period === 'day') return format(parseISO(periodKey), 'dd/MM/yyyy');
    if (period === 'month') return format(parseISO(periodKey + '-01'), 'MMM yyyy');
    return periodKey;
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">P/L Total Realizado</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${totalRealizedPL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(totalRealizedPL)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Todas las operaciones cerradas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Operaciones Cerradas</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalClosedTrades}</div>
            <p className="text-xs text-muted-foreground mt-1">Total de ventas registradas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mejor {period === 'month' ? 'Mes' : period === 'year' ? 'Año' : 'Día'}</CardTitle>
            {bestPeriod.pl >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-600" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-600" />
            )}
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${bestPeriod.pl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(bestPeriod.pl)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">{formatPeriodLabel(bestPeriod.period)}</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      {periodData.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>P/L por Período</CardTitle>
              <CardDescription>Rendimiento realizado</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={periodData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="period" 
                    tickFormatter={formatPeriodLabel}
                  />
                  <YAxis tickFormatter={(value) => formatCurrency(value)} />
                  <Tooltip 
                    formatter={(value) => formatCurrency(value as number)}
                    labelFormatter={formatPeriodLabel}
                  />
                  <Bar dataKey="pl" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>P/L Acumulado</CardTitle>
              <CardDescription>Evolución temporal</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={cumulativeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="period" 
                    tickFormatter={formatPeriodLabel}
                  />
                  <YAxis tickFormatter={(value) => formatCurrency(value)} />
                  <Tooltip 
                    formatter={(value) => formatCurrency(value as number)}
                    labelFormatter={formatPeriodLabel}
                  />
                  <Line type="monotone" dataKey="cumulative" stroke="#3b82f6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Period Tables */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Rendimientos por Período</CardTitle>
            <CardDescription>Desglose de operaciones cerradas</CardDescription>
          </div>
          {closedTrades.length > 0 && (
            <Button onClick={handleExport} variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Exportar CSV
            </Button>
          )}
        </CardHeader>
        <CardContent>
          <Tabs value={period} onValueChange={(v) => setPeriod(v as any)}>
            <TabsList className="grid w-full md:w-auto grid-cols-3">
              <TabsTrigger value="day">Diario</TabsTrigger>
              <TabsTrigger value="month">Mensual</TabsTrigger>
              <TabsTrigger value="year">Anual</TabsTrigger>
            </TabsList>

            <TabsContent value={period} className="mt-4">
              {periodData.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No hay operaciones cerradas registradas.
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Período</TableHead>
                        <TableHead className="text-right">P/L Total</TableHead>
                        <TableHead className="text-right">% Promedio</TableHead>
                        <TableHead className="text-right">Operaciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {periodData.map((item) => (
                        <TableRow key={item.period}>
                          <TableCell className="font-medium">{formatPeriodLabel(item.period)}</TableCell>
                          <TableCell className={`text-right font-medium ${item.pl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatCurrency(item.pl)}
                          </TableCell>
                          <TableCell className={`text-right ${item.avgPercent >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatPercent(item.avgPercent)}
                          </TableCell>
                          <TableCell className="text-right">{item.count}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Detailed Trades Table */}
      {closedTrades.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Detalle de Operaciones Cerradas</CardTitle>
            <CardDescription>Todas las ventas con cálculo FIFO</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Ticker</TableHead>
                    <TableHead className="text-right">Cantidad</TableHead>
                    <TableHead className="text-right">Precio Compra Prom.</TableHead>
                    <TableHead className="text-right">Precio Venta</TableHead>
                    <TableHead className="text-right">P/L Realizado</TableHead>
                    <TableHead className="text-right">% Retorno</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {closedTrades
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map((trade) => (
                      <TableRow key={trade.id}>
                        <TableCell>{format(parseISO(trade.date), 'dd/MM/yyyy')}</TableCell>
                        <TableCell className="font-medium">{trade.ticker}</TableCell>
                        <TableCell className="text-right">{trade.quantitySold}</TableCell>
                        <TableCell className="text-right">{formatCurrency(trade.buyPriceAvg)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(trade.sellPrice)}</TableCell>
                        <TableCell className={`text-right font-medium ${trade.realizedPL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatCurrency(trade.realizedPL)}
                        </TableCell>
                        <TableCell className={`text-right font-medium ${trade.percentPL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatPercent(trade.percentPL)}
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      <p className="text-xs text-muted-foreground">
        <strong>Disclaimer:</strong> Cálculos aproximados usando método FIFO. No es asesoramiento financiero. Verifique con su broker y contador.
      </p>
    </div>
  );
}
