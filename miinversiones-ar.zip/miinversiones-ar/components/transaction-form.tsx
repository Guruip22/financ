'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select } from './ui/select';
import { Button } from './ui/button';
import { Transaction, TransactionType } from '@/lib/types';
import { format } from 'date-fns';

interface TransactionFormProps {
  onSubmit: (transaction: Transaction) => void;
}

export function TransactionForm({ onSubmit }: TransactionFormProps) {
  const [formData, setFormData] = useState({
    ticker: '',
    type: 'compra' as TransactionType,
    cantidad: '',
    precio: '',
    fecha: format(new Date(), 'yyyy-MM-dd'),
    fees: '',
    nota: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.ticker || !formData.cantidad || !formData.precio) {
      alert('Por favor complete los campos requeridos');
      return;
    }

    const transaction: Transaction = {
      id: `txn-${Date.now()}-${Math.random()}`,
      ticker: formData.ticker.toUpperCase(),
      type: formData.type,
      cantidad: parseFloat(formData.cantidad),
      precio: parseFloat(formData.precio),
      fecha: new Date(formData.fecha).toISOString(),
      fees: formData.fees ? parseFloat(formData.fees) : 0,
      nota: formData.nota || undefined
    };

    onSubmit(transaction);
    
    // Reset form
    setFormData({
      ticker: '',
      type: 'compra',
      cantidad: '',
      precio: '',
      fecha: format(new Date(), 'yyyy-MM-dd'),
      fees: '',
      nota: ''
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Nueva Transacción</CardTitle>
        <CardDescription>Registre una compra o venta de activos</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="ticker">Ticker *</Label>
              <Input
                id="ticker"
                placeholder="GGAL, YPFD, etc."
                value={formData.ticker}
                onChange={(e) => setFormData({ ...formData, ticker: e.target.value.toUpperCase() })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Tipo *</Label>
              <Select
                id="type"
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as TransactionType })}
              >
                <option value="compra">Compra</option>
                <option value="venta">Venta</option>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cantidad">Cantidad *</Label>
              <Input
                id="cantidad"
                type="number"
                step="1"
                min="0"
                placeholder="100"
                value={formData.cantidad}
                onChange={(e) => setFormData({ ...formData, cantidad: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="precio">Precio (ARS) *</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                <Input
                  id="precio"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="1250.50"
                  className="pl-7"
                  value={formData.precio}
                  onChange={(e) => setFormData({ ...formData, precio: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="fecha">Fecha *</Label>
              <Input
                id="fecha"
                type="date"
                value={formData.fecha}
                onChange={(e) => setFormData({ ...formData, fecha: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fees">Comisiones (ARS)</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                <Input
                  id="fees"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="50.00"
                  className="pl-7"
                  value={formData.fees}
                  onChange={(e) => setFormData({ ...formData, fees: e.target.value })}
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="nota">Nota (opcional)</Label>
            <Input
              id="nota"
              placeholder="Comentarios adicionales..."
              value={formData.nota}
              onChange={(e) => setFormData({ ...formData, nota: e.target.value })}
            />
          </div>

          <Button type="submit" className="w-full">
            Agregar Transacción
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
