import { PortfolioData, Transaction, ClosedTrade, Alert } from './types';

const STORAGE_KEY = 'miinversiones-ar-data';

const DEFAULT_DATA: PortfolioData = {
  transactions: [],
  closedTrades: [],
  alertas: {}
};

export function loadPortfolioData(): PortfolioData {
  if (typeof window === 'undefined') return DEFAULT_DATA;
  
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error('Error loading portfolio data:', error);
  }
  
  return DEFAULT_DATA;
}

export function savePortfolioData(data: PortfolioData): void {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving portfolio data:', error);
  }
}

export function addTransaction(transaction: Transaction): void {
  const data = loadPortfolioData();
  data.transactions.push(transaction);
  savePortfolioData(data);
}

export function deleteTransaction(id: string): void {
  const data = loadPortfolioData();
  data.transactions = data.transactions.filter(t => t.id !== id);
  savePortfolioData(data);
}

export function addClosedTrades(trades: ClosedTrade[]): void {
  const data = loadPortfolioData();
  data.closedTrades.push(...trades);
  savePortfolioData(data);
}

export function updateAlertas(ticker: string, alert: Alert): void {
  const data = loadPortfolioData();
  data.alertas[ticker] = alert;
  savePortfolioData(data);
}

export function deleteAlerta(ticker: string): void {
  const data = loadPortfolioData();
  delete data.alertas[ticker];
  savePortfolioData(data);
}
