export type TransactionType = 'compra' | 'venta';

export interface Transaction {
  id: string;
  ticker: string;
  type: TransactionType;
  cantidad: number;
  precio: number;
  fecha: string; // ISO string
  fees?: number;
  nota?: string;
}

export interface ClosedTrade {
  id: string;
  date: string; // ISO string
  ticker: string;
  quantitySold: number;
  buyPriceAvg: number;
  sellPrice: number;
  realizedPL: number;
  percentPL: number;
  fees: number;
}

export interface Alert {
  stopLoss?: number;
  target?: number;
}

export interface PortfolioData {
  transactions: Transaction[];
  closedTrades: ClosedTrade[];
  alertas: Record<string, Alert>;
}

export interface Position {
  ticker: string;
  quantity: number;
  avgBuyPrice: number;
  currentPrice: number;
  currentValue: number;
  unrealizedPL: number;
  unrealizedPLPercent: number;
  investedCapital: number;
}

export interface MarketData {
  symbol: string;
  c: number; // current price
  pct_change: number;
  bid?: number;
  ask?: number;
}

export interface RealizedPeriodData {
  period: string;
  totalPL: number;
  avgPercent: number;
  tradesCount: number;
  byTicker: Record<string, { pl: number; count: number }>;
}
