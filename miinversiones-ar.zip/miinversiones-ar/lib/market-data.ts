import { MarketData } from './types';

const ENDPOINTS = [
  'https://data912.com/live/arg_stocks',
  'https://data912.com/live/arg_cedears',
  'https://data912.com/live/arg_bonds',
  'https://data912.com/live/arg_notes',
];

export async function fetchAllPrices(): Promise<Record<string, MarketData>> {
  const priceMap: Record<string, MarketData> = {};
  
  try {
    const responses = await Promise.allSettled(
      ENDPOINTS.map(url => 
        fetch(url, { 
          cache: 'no-store',
          next: { revalidate: 0 }
        }).then(res => {
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
          return res.json();
        })
      )
    );

    responses.forEach(result => {
      if (result.status === 'fulfilled' && Array.isArray(result.value)) {
        result.value.forEach((data: MarketData) => {
          if (data.symbol) {
            priceMap[data.symbol.toUpperCase()] = data;
          }
        });
      }
    });
  } catch (error) {
    console.error('Error fetching prices:', error);
  }

  return priceMap;
}

export function getPriceForTicker(ticker: string, priceMap: Record<string, MarketData>): number | null {
  const data = priceMap[ticker.toUpperCase()];
  return data?.c ?? null;
}

export function getMarketDataForTicker(ticker: string, priceMap: Record<string, MarketData>): MarketData | null {
  return priceMap[ticker.toUpperCase()] ?? null;
}
