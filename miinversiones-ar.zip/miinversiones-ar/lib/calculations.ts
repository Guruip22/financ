import { Transaction, ClosedTrade, Position } from './types';
import { format, parseISO, startOfMonth, startOfYear } from 'date-fns';

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('es-AR', {
    style: 'currency',
    currency: 'ARS',
    minimumFractionDigits: 2,
  }).format(amount);
}

export function formatPercent(value: number): string {
  return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
}

interface BuyRecord {
  precio: number;
  cantidad: number;
  fees: number;
  fecha: string;
  id: string;
}

export function processSale(
  ticker: string,
  sellQty: number,
  sellPrice: number,
  sellDate: string,
  sellFees: number,
  transactions: Transaction[]
): ClosedTrade[] {
  // Get all buys for this ticker, sorted by date (FIFO)
  const buys = transactions
    .filter(t => t.ticker === ticker && t.type === 'compra')
    .sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime())
    .map(t => ({
      precio: t.precio,
      cantidad: t.cantidad,
      fees: t.fees || 0,
      fecha: t.fecha,
      id: t.id
    }));

  // Get all previous sells for this ticker to calculate remaining quantities
  const previousSells = transactions
    .filter(t => t.ticker === ticker && t.type === 'venta' && new Date(t.fecha) < new Date(sellDate))
    .sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime());

  // Calculate remaining quantities after previous sells
  const buyQueue: BuyRecord[] = [];
  let totalSold = previousSells.reduce((sum, sell) => sum + sell.cantidad, 0);
  
  for (const buy of buys) {
    let remainingQty = buy.cantidad;
    
    while (totalSold > 0 && remainingQty > 0) {
      const qtyToDeduct = Math.min(remainingQty, totalSold);
      remainingQty -= qtyToDeduct;
      totalSold -= qtyToDeduct;
    }
    
    if (remainingQty > 0) {
      buyQueue.push({ ...buy, cantidad: remainingQty });
    }
  }

  // Now process this sell
  const closedTrades: ClosedTrade[] = [];
  let remainingSellQty = sellQty;
  let totalBuyCost = 0;
  let totalBuyFees = 0;

  for (const buy of buyQueue) {
    if (remainingSellQty <= 0) break;

    const qtyToSell = Math.min(remainingSellQty, buy.cantidad);
    const buyCost = buy.precio * qtyToSell;
    const buyFeesProrated = (buy.fees / buy.cantidad) * qtyToSell;
    
    totalBuyCost += buyCost;
    totalBuyFees += buyFeesProrated;
    remainingSellQty -= qtyToSell;
  }

  if (sellQty > 0 && totalBuyCost > 0) {
    const avgBuyPrice = totalBuyCost / sellQty;
    const totalCost = totalBuyCost + totalBuyFees + sellFees;
    const totalRevenue = sellPrice * sellQty;
    const realizedPL = totalRevenue - totalCost;
    const percentPL = ((sellPrice - avgBuyPrice) / avgBuyPrice) * 100;

    closedTrades.push({
      id: `closed-${Date.now()}-${Math.random()}`,
      date: sellDate,
      ticker,
      quantitySold: sellQty,
      buyPriceAvg: avgBuyPrice,
      sellPrice,
      realizedPL,
      percentPL,
      fees: totalBuyFees + sellFees
    });
  }

  return closedTrades;
}

export function calculatePositions(
  transactions: Transaction[],
  priceMap: Record<string, number>
): Position[] {
  const positionMap = new Map<string, {
    totalQty: number;
    totalCost: number;
    totalFees: number;
  }>();

  // Calculate net positions considering all transactions
  transactions.forEach(t => {
    const current = positionMap.get(t.ticker) || {
      totalQty: 0,
      totalCost: 0,
      totalFees: 0
    };

    if (t.type === 'compra') {
      current.totalQty += t.cantidad;
      current.totalCost += t.precio * t.cantidad;
      current.totalFees += t.fees || 0;
    } else {
      current.totalQty -= t.cantidad;
      // For sells, we don't add to cost (it's realized)
    }

    positionMap.set(t.ticker, current);
  });

  const positions: Position[] = [];

  positionMap.forEach((data, ticker) => {
    if (data.totalQty > 0) {
      const avgBuyPrice = (data.totalCost + data.totalFees) / data.totalQty;
      const currentPrice = priceMap[ticker] || 0;
      const currentValue = currentPrice * data.totalQty;
      const investedCapital = data.totalCost + data.totalFees;
      const unrealizedPL = currentValue - investedCapital;
      const unrealizedPLPercent = investedCapital > 0 ? (unrealizedPL / investedCapital) * 100 : 0;

      positions.push({
        ticker,
        quantity: data.totalQty,
        avgBuyPrice,
        currentPrice,
        currentValue,
        unrealizedPL,
        unrealizedPLPercent,
        investedCapital
      });
    }
  });

  return positions.sort((a, b) => b.currentValue - a.currentValue);
}

export function exportToCSV(data: any[], filename: string) {
  if (data.length === 0) return;

  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => {
        const value = row[header];
        if (typeof value === 'string' && value.includes(',')) {
          return `"${value}"`;
        }
        return value;
      }).join(',')
    )
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function groupRealizedByPeriod(
  closedTrades: ClosedTrade[],
  period: 'day' | 'month' | 'year'
): Map<string, {
  totalPL: number;
  trades: ClosedTrade[];
  avgPercent: number;
}> {
  const grouped = new Map();

  closedTrades.forEach(trade => {
    let key: string;
    const date = parseISO(trade.date);

    if (period === 'day') {
      key = format(date, 'yyyy-MM-dd');
    } else if (period === 'month') {
      key = format(startOfMonth(date), 'yyyy-MM');
    } else {
      key = format(startOfYear(date), 'yyyy');
    }

    if (!grouped.has(key)) {
      grouped.set(key, {
        totalPL: 0,
        trades: [],
        avgPercent: 0
      });
    }

    const group = grouped.get(key);
    group.totalPL += trade.realizedPL;
    group.trades.push(trade);
  });

  // Calculate average percent
  grouped.forEach((value, key) => {
    const avgPercent = value.trades.reduce((sum, t) => sum + t.percentPL, 0) / value.trades.length;
    value.avgPercent = avgPercent;
  });

  return grouped;
}
