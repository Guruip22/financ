# 🚀 MiInversiones AR - Guía Completa de Instalación y Uso

## 📋 Tabla de Contenidos
1. [Instalación](#instalación)
2. [Estructura del Proyecto](#estructura-del-proyecto)
3. [Características Principales](#características-principales)
4. [Guía de Uso](#guía-de-uso)
5. [Ejemplos de Uso](#ejemplos-de-uso)
6. [Solución de Problemas](#solución-de-problemas)

---

## 🔧 Instalación

### Requisitos Previos
- Node.js 18+ instalado
- npm o yarn

### Pasos de Instalación

```bash
# 1. Navegar al directorio del proyecto
cd miinversiones-ar

# 2. Instalar dependencias
npm install

# 3. Ejecutar en modo desarrollo
npm run dev

# 4. Abrir en el navegador
# http://localhost:3000
```

### Comandos Disponibles

```bash
npm run dev      # Desarrollo con hot reload
npm run build    # Compilar para producción
npm start        # Ejecutar versión de producción
npm run lint     # Ejecutar linter
```

---

## 📁 Estructura del Proyecto

```
miinversiones-ar/
├── app/
│   ├── globals.css          # Estilos globales y variables CSS
│   ├── layout.tsx            # Layout raíz con tema
│   └── page.tsx              # Página principal con lógica de estado
├── components/
│   ├── ui/                   # Componentes base Shadcn UI
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── input.tsx
│   │   ├── label.tsx
│   │   ├── select.tsx
│   │   ├── table.tsx
│   │   └── tabs.tsx
│   ├── alerts.tsx            # Sistema de alertas de precios
│   ├── dark-mode-toggle.tsx  # Toggle modo oscuro/claro
│   ├── portfolio-dashboard.tsx  # Dashboard principal
│   ├── realized-returns.tsx  # Rendimientos realizados (FIFO)
│   ├── transaction-form.tsx  # Formulario de transacciones
│   └── transaction-history.tsx  # Historial completo
├── lib/
│   ├── calculations.ts       # Lógica de cálculos FIFO y P/L
│   ├── market-data.ts        # Fetching de cotizaciones
│   ├── storage.ts            # Persistencia en localStorage
│   └── types.ts              # Definiciones TypeScript
├── package.json
├── tsconfig.json
├── tailwind.config.js
└── next.config.js
```

---

## ✨ Características Principales

### 1. Dashboard de Portfolio
- **Vista Consolidada**: Posiciones actuales con métricas en tiempo real
- **Cards de Resumen**: 
  - Valor Total del Portfolio
  - Capital Invertido (costo + comisiones)
  - P/L No Realizado (ganancia/pérdida actual)
  - Rendimiento % total
- **Gráficos Interactivos**:
  - Pie Chart: Distribución del portfolio por activo
  - Bar Chart: P/L no realizado por ticker
- **Actualización de Precios**: Botón para fetch manual de cotizaciones

### 2. Sistema de Transacciones
- Formulario completo con validación
- Campos: Ticker, Tipo (Compra/Venta), Cantidad, Precio, Fecha, Comisiones, Nota
- Conversión automática de ticker a mayúsculas
- Formato de moneda con símbolo $ para ARS

### 3. Cálculo FIFO Automático
Cuando registras una **venta**:
1. El sistema busca las compras más antiguas del mismo ticker
2. Calcula el costo promedio de compra (incluyendo comisiones prorrateadas)
3. Genera un "closed trade" con:
   - Precio promedio de compra
   - Precio de venta
   - P/L realizado = (Precio venta × cantidad) - (Precio compra × cantidad) - comisiones
   - % de retorno

### 4. Rendimientos Realizados
- **Vistas por Período**: Diario, Mensual, Anual
- **Tablas Agregadas**: Total P/L, % promedio, número de trades
- **Gráficos**:
  - Bar Chart: P/L por período
  - Line Chart: P/L acumulado en el tiempo
- **Cards de Resumen**:
  - Total Realizado (all-time)
  - Total de Operaciones Cerradas
  - Mejor Período (mes/año con mayor ganancia)
- **Exportar a CSV**: Descargar datos de rendimientos

### 5. Sistema de Alertas
- Configurar **Stop Loss** y **Target Price** por ticker
- Banner de alertas cuando se disparan
- Indicadores visuales:
  - 🔴 Rojo: Stop Loss alcanzado
  - 🟢 Verde: Target Price alcanzado
- Tabla con estado en tiempo real

### 6. Integración con data912.com
- Fetch de cotizaciones desde 4 endpoints:
  - `/live/arg_stocks` - Acciones argentinas
  - `/live/arg_cedears` - CEDEARs
  - `/live/arg_bonds` - Bonos
  - `/live/arg_notes` - Notas
- Actualización ~20 segundos
- Manejo de errores (muestra "N/A" si no hay dato)

---

## 📖 Guía de Uso

### Agregar una Compra

1. Ir a la pestaña **Transacciones**
2. Completar el formulario:
   - **Ticker**: GGAL
   - **Tipo**: Compra
   - **Cantidad**: 100
   - **Precio**: $1,250.50
   - **Fecha**: (default hoy)
   - **Comisiones**: $50 (opcional)
   - **Nota**: "Compra estratégica" (opcional)
3. Clic en **Agregar Transacción**

### Agregar una Venta (con FIFO)

1. Ir a **Transacciones**
2. Completar:
   - **Ticker**: GGAL
   - **Tipo**: Venta
   - **Cantidad**: 50
   - **Precio**: $1,400.00
   - **Comisiones**: $40
3. El sistema automáticamente:
   - Busca las 50 acciones más antiguas de GGAL
   - Calcula el precio promedio de compra de esas 50
   - Genera un "closed trade" con el P/L realizado
   - Lo guarda en la sección **Rendimientos Realizados**

### Ver Rendimientos Realizados

1. Ir a **Rendimientos**
2. Seleccionar período: Diario, Mensual, Anual
3. Ver:
   - Tablas con totales por período
   - Gráficos de evolución
   - Detalle completo de cada venta
4. Exportar a CSV si es necesario

### Configurar Alertas

1. Ir a **Alertas**
2. Completar:
   - **Ticker**: GGAL
   - **Stop Loss**: $1,100 (vender si baja de este precio)
   - **Target Price**: $1,600 (vender si sube a este precio)
3. Guardar
4. Si el precio alcanza cualquiera de los valores:
   - Aparecerá un banner amarillo en la parte superior
   - La fila en la tabla se resaltará

### Actualizar Cotizaciones

1. En el **Dashboard**, clic en **Actualizar Cotizaciones**
2. El sistema fetchea precios de data912.com
3. Todos los valores actuales se actualizan
4. Los P/L no realizados se recalculan

---

## 💡 Ejemplos de Uso

### Ejemplo 1: Portfolio Básico

**Operaciones:**
1. Compra 100 GGAL @ $1,000 (comisiones $30)
2. Compra 50 YPFD @ $2,500 (comisiones $50)
3. Venta 40 GGAL @ $1,200 (comisiones $20)

**Resultados:**

*Dashboard:*
- GGAL: 60 acciones, costo prom $1,003, valor actual: $72,000 (si precio actual $1,200)
- YPFD: 50 acciones, costo prom $2,501, valor actual: $125,000

*Rendimientos Realizados:*
- GGAL: 40 vendidas
  - Precio compra prom: $1,003 (incluye comisiones prorrateadas)
  - Precio venta: $1,200
  - P/L: ($1,200 - $1,003) × 40 - $20 = $7,860
  - %: 19.64%

### Ejemplo 2: Múltiples Compras FIFO

**Operaciones:**
1. Compra 100 GGAL @ $1,000 (15/01/2024)
2. Compra 100 GGAL @ $1,100 (01/02/2024)
3. Compra 100 GGAL @ $1,200 (15/02/2024)
4. Venta 150 GGAL @ $1,300 (01/03/2024)

**FIFO:**
- Vende las primeras 100 @ $1,000 (15/01) → P/L: $30,000
- Vende 50 de las 100 @ $1,100 (01/02) → P/L: $10,000
- Total P/L: $40,000 (aprox, menos comisiones)

---

## 🛠️ Solución de Problemas

### No se actualizan los precios

**Problema**: Al clic en "Actualizar Cotizaciones", los precios quedan en "N/A"

**Causas posibles:**
1. data912.com está caído
2. El ticker no existe en ninguno de los endpoints
3. Problema de CORS (en producción)

**Soluciones:**
- Verificar que el ticker esté escrito correctamente
- Esperar unos minutos y reintentar
- Verificar en data912.com si el ticker existe
- En producción: considerar un proxy backend

### Los datos se borran al cerrar el navegador

**Problema**: Al abrir la app, no hay transacciones

**Causa**: localStorage fue limpiado

**Soluciones:**
- No usar modo incógnito
- No limpiar datos del sitio
- Exportar datos a CSV regularmente como backup

### El cálculo FIFO parece incorrecto

**Problema**: El P/L realizado no coincide con expectativas

**Causas:**
- Las comisiones están incluidas en el costo promedio
- FIFO usa las compras más antiguas primero
- Si eliminaste transacciones antiguas, el cálculo puede estar desactualizado

**Soluciones:**
- Revisar el historial completo de transacciones
- Verificar las fechas de las compras
- No eliminar transacciones antiguas si tienes ventas posteriores

### Modo oscuro no funciona

**Problema**: El toggle no cambia el tema

**Solución:**
- Limpiar localStorage: `localStorage.removeItem('theme')`
- Recargar la página
- Verificar que JavaScript esté habilitado

---

## 📊 Datos Técnicos

### Formato de localStorage

```json
{
  "transactions": [
    {
      "id": "txn-1234567890-0.123",
      "ticker": "GGAL",
      "type": "compra",
      "cantidad": 100,
      "precio": 1250.5,
      "fecha": "2024-01-15T00:00:00.000Z",
      "fees": 50,
      "nota": "Compra estratégica"
    }
  ],
  "closedTrades": [
    {
      "id": "closed-1234567890-0.456",
      "date": "2024-02-01T00:00:00.000Z",
      "ticker": "GGAL",
      "quantitySold": 50,
      "buyPriceAvg": 1253,
      "sellPrice": 1400,
      "realizedPL": 7310,
      "percentPL": 11.73,
      "fees": 90
    }
  ],
  "alertas": {
    "GGAL": {
      "stopLoss": 1100,
      "target": 1600
    }
  }
}
```

### API de data912.com

**Request:**
```
GET https://data912.com/live/arg_stocks
```

**Response:**
```json
[
  {
    "symbol": "GGAL",
    "c": 1250.5,
    "pct_change": 2.5,
    "bid": 1249,
    "ask": 1252
  }
]
```

---

## ⚠️ Disclaimer Legal

**IMPORTANTE - LEA CUIDADOSAMENTE:**

Esta aplicación es **exclusivamente para uso educativo y personal**. NO constituye asesoramiento financiero, de inversión, contable o legal.

- Los cálculos son aproximados y pueden contener errores
- Los precios de data912.com son indicativos y pueden no reflejar precios reales de mercado
- Siempre verifique operaciones y saldos con su broker oficial
- Consulte con un profesional certificado para decisiones de inversión
- Los datos en localStorage son locales y no respaldados
- El autor no se responsabiliza por pérdidas financieras

**Uso bajo su propio riesgo.**

---

## 🤝 Contribuciones

Si encontrás un bug o tenés una sugerencia:
1. Crear un issue en GitHub
2. Fork del proyecto
3. Pull request con descripción detallada

---

## 📄 Licencia

MIT License - Ver LICENSE file

---

## 👨‍💻 Autor

Creado por [@Guru_itm](https://twitter.com/Guru_itm)

**¿Preguntas?** Twitter DM o GitHub Issues

---

## 🎯 Próximas Mejoras Planeadas

- [ ] Importar transacciones desde CSV
- [ ] Gráficos de evolución histórica del portfolio
- [ ] Exportar reportes en PDF
- [ ] Integración con más fuentes de datos
- [ ] Calculadora de impuestos (ganancia de capital)
- [ ] Comparación con índices (Merval, S&P500)
- [ ] Modo multi-portfolio (cuentas separadas)
- [ ] Sincronización en la nube (opcional)
- [ ] Notificaciones push para alertas
- [ ] Análisis de diversificación del portfolio

---

**¡Que disfrutes invirtiendo! 📈**
